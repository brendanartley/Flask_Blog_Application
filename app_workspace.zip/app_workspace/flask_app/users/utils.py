import os
import secrets
from PIL import Image
from flask import url_for, current_app
from flask_mail import Message
from flask_app import mail

def save_picture(form_picture):
    #getting save_path and fname
    random_hex = secrets.token_hex(8)#create 8byte hex
    _, f_ext = os.path.splitext(form_picture.filename)#split filename and extension
    picture_fn = random_hex + f_ext
    picture_path = os.path.join(current_app.root_path, 'static/profile_pics', picture_fn)
    #resizing image with PIL
    output_size = (125, 125)
    i = Image.open(form_picture)
    i.thumbnail(output_size)
    i.save(picture_path)
    return picture_fn

def send_reset_email(user):
    #enable gmail less secure app access - https://myaccount.google.com/lesssecureapps
    token = user.get_reset_token()
    msg = Message('Password Reset Request', sender='noreply@demo.com', recipients=[user.email])
    msg.body = '''To reset your password, visit the following link:

{}

If you did not make this request, ignore this email and no changes will be made
    '''.format(url_for('users.reset_token', token=token, _external=True)) 
    #external = True gives a complete URL vs Relative URL
    mail.send(msg)