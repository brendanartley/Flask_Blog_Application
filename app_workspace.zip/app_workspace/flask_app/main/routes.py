from flask import render_template, request, Blueprint
from flask_app.models import Post

main = Blueprint('main', __name__)

#both / and /home will go to homepage
@main.route("/")
@main.route("/home")
def home():
    page = request.args.get('page', default=1, type=int) #allows controlled number of posts per page
    posts=Post.query.order_by(Post.date_posted.desc()).paginate(per_page=5, page=page) #loop through w/ jinja on index.html page
    return render_template('index.html', posts = posts)


@main.route("/about")
def about():
    return render_template('about.html', title = "About")